<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
	</head>
	<body>
		<?php
		/*
         * Crea un método para añadir un contacto a la Agenda, otro para un contacto y uno que convierta a cadena todo el objeto 
         * Agenda, de manera que en HTML se muestre un contacto de la agenda en cada línea (tendrás que poner <br> para los 
         * saltos de línea). Guarda esta clase en un fichero llamado agenda.inc.php.
         * 
         * Finalmente, crea una página php llamada t3-act1.php que cree un objeto Agenda, añada tres contactos a la misma y la 
         *  muestre en la página. Después, eliminará el primer contacto y volverá a mostrar la agenda en la página.
         */

		require_once('Agenda.inc.php');

		$agenda = new Agenda();

		$contactoa = new Contacto('01', 'German', 'Navarro', 'Diaz', '12345678');
		$contactob = new Contacto('02', 'john', 'Doe', 'Dae', '012345678');
		$contactoc = new Contacto('03', 'Jane', 'Dae', 'Doe', '912345678');


		$agenda->addContacto($contactoa);
		$agenda->addContacto($contactob);
		$agenda->addContacto($contactoc);

		print $agenda->__toString();
		
		print "Read--------------<br>";

		print $agenda->readContacto(2);

		print "Del--------------<br>";
		
		$agenda->delContacto(0);
		print $agenda->__toString();
		
		

		?>
	</body>
</html>
